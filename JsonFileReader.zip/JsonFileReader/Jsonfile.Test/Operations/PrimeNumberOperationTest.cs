﻿using JsonFileReader.Operations;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Jsonfile.Test
{
    [TestClass]
    public class PrimeNumberOperationTest
    {
        [TestMethod]
        [TestCategory("PrimeNumberOperation")]
        public void IsTrue_ReturnPrime_True()
        {
            //Arrange
            string value = "17";
            PrimeNumberOperation prime = new PrimeNumberOperation();

            //Act
            var result = prime.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(bool));
            Assert.IsTrue(result);
        }


        [TestMethod]
        [TestCategory("PrimeNumberOperation")]
        public void IsTrue_ReturnPrime_False()
        {
            //Arrange
            string value = "6";
            PrimeNumberOperation prime = new PrimeNumberOperation();

            //Act
            var result = prime.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(bool));
            Assert.IsFalse(result);
        }

        [TestMethod]
        [TestCategory("PrimeNumberOperation")]
        [ExpectedException(typeof(FormatException))]
        public void IsTrue_ReturnsFormatException_ForStringValue()
        {
            //Arrange
            string value = "mock";
            PrimeNumberOperation prime = new PrimeNumberOperation();

            //Act
            var result = prime.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(FormatException));
        }

    }
}
