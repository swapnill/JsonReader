﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using JsonFileReader.Factory;
using JsonFileReader.Operations;
using JsonFileReader;
using System.Collections.Generic;
using NSubstitute;
using System.IO;
using System.Reflection;

namespace Jsonfile.Test
{
    [TestClass]
    public class PalendromeOperationTest
    {  
        [TestMethod]
        [TestCategory("PalindromeOperations")]
        public void IsTrue_ReturnsPalemdrome_True()
        {
            //Arrange
            string value = "mam";
            PalindromeOperation palendrome = new PalindromeOperation();

            //Act
            var result = palendrome.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(bool));
            Assert.IsTrue(result);
        }

        [TestMethod]
        [TestCategory("PalindromeOperations")]
        public void IsTrue_ReturnsPalemdrome_False()
        {
            //Arrange
            string value = "man";
            PalindromeOperation palendrome = new PalindromeOperation();

            //Act
            var result = palendrome.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(bool));
            Assert.IsFalse(result);
        }


        [TestMethod]
        [TestCategory("PalindromeOperations")]
        public void IsTrue_Returns_False_IfValueIsNumeric()
        {
            //Arrange
            string value = "123";
            PalindromeOperation palendrome = new PalindromeOperation();

            //Act
            var result = palendrome.IsTrue(value);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(bool));
            Assert.IsFalse(result);
        }

       
        
        

    }
}
