﻿using JsonFileReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;

namespace Jsonfile.Test
{
    [TestClass]
    public class HelperTest
    {
        [TestMethod]
        [TestCategory("Helper")]
        public void ProcessFile_ReturnsFileResultList()
        {
            //Arrange            
            Helper helper = new Helper();
            var output = new StringWriter();
            Console.SetOut(output);
            string path = Path.Combine(Environment.CurrentDirectory, @"FilePath");
            var input = new StringReader(path);
            Console.SetIn(input);

            //helper.ReadJsonFiles(Arg.Any<string[]>()).Returns(fileResult);

            //Act
            var result = helper.ProcessFile();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(List<FileResult>));

        }
    }
}
