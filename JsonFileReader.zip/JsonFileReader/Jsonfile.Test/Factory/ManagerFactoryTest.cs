﻿using JsonFileReader.Factory;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Jsonfile.Test.Factory
{
    [TestClass]
    public class ManagerFactoryTest
    {

        [TestMethod]
        [TestCategory("Manager")]
        public void MathCalculation_ReturnsPalendromeClass()
        {
            //Arrange
            var key = "palindrome";
            ManagerFactory math = new ManagerFactory();

            //Act
            var result = math.MathCalculation(key);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(JsonFileReader.Operations.PalindromeOperation));
        }

        [TestMethod]
        [TestCategory("Manager")]
        public void MathCalculation_ReturnsPrimeClass()
        {
            //Arrange
            var key = "prime";
            ManagerFactory math = new ManagerFactory();

            //Act
            var result = math.MathCalculation(key);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(JsonFileReader.Operations.PrimeNumberOperation));
        }

        [TestMethod]
        [TestCategory("Manager")]
        public void MathCalculation_ReturnsNull()
        {
            //Arrange
            var key = "mock";
            ManagerFactory math = new ManagerFactory();

            //Act
            var result = math.MathCalculation(key);

            //Assert
            Assert.IsNull(result);
        }

    }
}
