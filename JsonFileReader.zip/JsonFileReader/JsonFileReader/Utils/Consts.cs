﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader.Utils
{
   public class Consts
    {
        public static string key => "key";
        public static string value => "value";
        public static string prime => "prime";
        public static string palindrome => "palindrome";

    }
}
