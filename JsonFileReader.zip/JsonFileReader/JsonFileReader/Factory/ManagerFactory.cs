﻿using JsonFileReader.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader.Factory
{
    public class ManagerFactory
    {
        public IManagerFactory MathCalculation(string key)
        {
            IManagerFactory returnValue = null;

            switch (key)
            {
                case "prime":
                    returnValue = new PrimeNumberOperation();
                    break;
                case "palindrome":
                    returnValue = new PalindromeOperation();
                    break;
                default:
                    break;
            }

            return returnValue;
        }
    }
}
