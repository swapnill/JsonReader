﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader.Operations
{
   public interface IManagerFactory
    {
        bool IsTrue(string value);
    }
}
