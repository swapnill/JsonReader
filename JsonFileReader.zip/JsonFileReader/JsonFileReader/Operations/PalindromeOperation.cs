﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader.Operations
{
    public class PalindromeOperation : IManagerFactory
    {
        /// <summary>
        /// Check if input string is Palindrome
        /// </summary>
        /// <param name="value">string</param>
        /// <returns>bool</returns>
        public bool IsTrue(string value)
        {
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    int min = 0;
                    int max = value.Length - 1;

                    while (true)
                    {
                        if (min > max)
                        {
                            return true;
                        }
                        char first = value[min];
                        char last = value[max];

                        // Scan forward for a while invalid.
                        while (!char.IsLetterOrDigit(first))
                        {
                            min++;
                            if (min > max)
                            {
                                return true;
                            }
                            first = value[min];
                        }

                        // Scan backward for b while invalid.
                        while (!char.IsLetterOrDigit(last))
                        {
                            max--;
                            if (min > max)
                            {

                                return true;
                            }
                            last = value[max];
                        }

                        if (char.ToLower(first) != char.ToLower(last))
                        {

                            return false;
                        }
                        min++;
                        max--;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;                
            }
        }
    }
}
