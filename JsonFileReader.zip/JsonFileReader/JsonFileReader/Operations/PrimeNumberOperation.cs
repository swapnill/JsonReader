﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader.Operations
{
    public class PrimeNumberOperation : IManagerFactory
    {
        /// <summary>
        /// Check if input is Prime
        /// </summary>
        /// <param name="value">string</param>
        /// <returns>bool</returns>
        public bool IsTrue(string value)
        {
            try
            {
                int number = Convert.ToInt32(value), count, remainder = 0;

                bool flag = true;

                remainder = number / 2;
                for (count = 2; count <= remainder; count++)
                {
                    if (number % count == 0)
                    {
                        flag = false;
                        break;
                    }                    
                }
                
                return flag;
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} is not an integer", value);
                throw ex;
            }
        }
    }
}
