﻿using JsonFileReader.Factory;
using JsonFileReader.Operations;
using JsonFileReader.Utils;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace JsonFileReader
{
    public class Helper
    {
        /// <summary>
        /// Logic to get json filepath from user
        /// </summary>
        /// <returns>List<FileResult></returns>
        public List<FileResult> ProcessFile()
        {
            try
            {
                #region variable declaration
                string filePath = string.Empty;
                List<FileResult> fileInfo = new List<FileResult>();
                bool directoryFound = true;
                #endregion

                //Run until valid path is provided
                do
                {
                    if (!directoryFound)
                    {
                        Console.WriteLine("This directory not found: {0}. Please double check file path.\n", filePath);
                    }

                    Console.Write("Please Enter Folder Path: ");

                    filePath = Console.ReadLine();

                    directoryFound = Directory.Exists(filePath);

                    if (directoryFound)
                    {
                        //Get json files from available location
                        string[] filePaths = Directory.GetFiles(filePath, "*.json");

                        //Check if filepath conatins any json file
                        if (filePaths.Count() == 0)
                        {
                            Console.WriteLine("No Json files are present at location : {0}. Please double check file path.\n", filePath);
                        }
                        else
                        {
                            //Method to read and process json file
                            fileInfo = ReadJsonFiles(filePaths);
                        }
                    }

                } while (!directoryFound);

                return fileInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Logic to read json files
        /// </summary>
        /// <param name="path">string[]</param>
        /// <returns>List<FileResult></returns>
        public List<FileResult> ReadJsonFiles(string[] path)
        {
            try
            {
                var details = new List<FileResult>();
                foreach (var item in path)
                {
                    string data = System.IO.File.ReadAllText(item);
                    JArray jobj = JArray.Parse(data);

                    // JavaScriptSerializer serializer = new JavaScriptSerializer();
                    // var getData = serializer.Deserialize<Dictionary<string, EndPoint[]>>(data);

                    ManagerFactory calFactory = new ManagerFactory();
                    IManagerFactory calculationResult;
                    foreach (var newData in jobj)
                    {
                        calculationResult = calFactory.MathCalculation(newData[Consts.key].ToString().ToLower());
                        //Method to get result for each key value pair
                        bool result = calculationResult.IsTrue(newData[Consts.value].ToString());
                        details.Add(new FileResult
                        {
                            Key = newData[Consts.key].ToString().ToLower(),
                            Value = newData[Consts.value].ToString(),
                            Result = result
                        });
                    }
                }
                return details;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
