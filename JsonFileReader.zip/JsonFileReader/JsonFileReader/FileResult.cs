﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonFileReader
{
   public class FileResult
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public bool Result { get; set; }

    }
}
