﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using JsonFileReader.Factory;
using JsonFileReader.Operations;

namespace JsonFileReader
{
    public class Program
    {
        static void Main(string[] args)
        {
            Helper helper = new Helper();
            List<FileResult> result = helper.ProcessFile();

            foreach (var item in result)
            {
                Console.WriteLine("\nKey : " + item.Key + "\nValue : " + item.Value + "\nResult: " + item.Result + "\n");
            }
            Console.Read();

        }





    }
}
